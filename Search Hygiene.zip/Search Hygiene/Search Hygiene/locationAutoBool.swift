//
//  locationAutoBool.swift
//  Search Hygiene
//
//  Created by Joel Cummings on 18/04/2018.
//  Copyright © 2018 Joel Cummings. All rights reserved.
//

import Foundation

class locationAutoBool{
    //Store location auto update bool here for access by other view controllers
    static let sharedInstance = locationAutoBool()
    var isAutoLocation = true
}
